import test from 'node:test';
import assert from 'node:assert/strict';
import {
  CATEGORIES, formatDuration, formatPace, todayISO, validateRun, leaderboard, csvEscape, toCSV,
} from '../src/model.js';

const now = new Date(2026, 9, 28, 12, 0, 0);
const form = (overrides = {}) => ({
  runnerName: '  Élodie   Rao  ', categoryId: '5k', date: '2026-10-20',
  hours: '0', minutes: '25', seconds: '00', activityUrl: '', ...overrides,
});
const run = (overrides = {}) => ({
  id: 'a', runner_name: 'Asha', runner_key: 'asha', category_id: '5k',
  run_date: '2026-10-20', duration_seconds: 1500, activity_url: null, ...overrides,
});

test('categories use a precise half marathon distance and stable IDs', () => {
  assert.deepEqual(CATEGORIES.map(({ id, distanceKm }) => [id, distanceKm]), [
    ['3k', 3], ['5k', 5], ['10k', 10], ['half', 21.1],
  ]);
});

test('time and pace formatting carry rounded seconds correctly', () => {
  assert.equal(formatDuration(1500), '25:00');
  assert.equal(formatDuration(5100), '1:25:00');
  assert.equal(formatDuration(3599.6), '1:00:00');
  assert.equal(formatDuration(0), '0:00');
  assert.equal(formatPace(1500, 5), '5:00');
  assert.equal(formatPace(1499, 5), '5:00');
  assert.equal(formatPace(7200, 21.1), '5:41');
  assert.equal(formatPace(1, 0), '—');
  assert.equal(formatDuration(NaN), '—');
  assert.equal(formatDuration(-1), '—');
});

test('todayISO reads local date parts', () => {
  assert.equal(todayISO(new Date(2026, 0, 2, 0, 1)), '2026-01-02');
  assert.equal(todayISO(new Date(2026, 11, 31, 23, 59)), '2026-12-31');
  assert.throws(() => todayISO(new Date('invalid')), /valid current date/);
});

test('validation normalizes display whitespace and a Unicode case-insensitive identity', () => {
  assert.deepEqual(validateRun(form(), { now }), {
    runner_name: 'Élodie Rao', runner_key: 'élodie rao', category_id: '5k',
    run_date: '2026-10-20', duration_seconds: 1500, activity_url: null,
  });
  const lower = validateRun(form({ runnerName: 'éLODIE rAO' }), { now });
  assert.equal(lower.runner_key, 'élodie rao');
  assert.equal(validateRun(form({ runnerKey: '  Club-123  ' }), { now }).runner_key, 'club-123');
});

test('validation accepts form strings and a single positive second', () => {
  assert.equal(validateRun(form({ hours: '', minutes: '', seconds: '01' }), { now }).duration_seconds, 1);
  assert.equal(validateRun(form({ hours: 23, minutes: 59, seconds: 59 }), { now }).duration_seconds, 86399);
  assert.equal(validateRun(form({ runnerName: '李明' }), { now }).runner_name, '李明');
});

test('validation rejects fractional, negative, overflowing, or zero durations', () => {
  for (const changes of [
    { minutes: '1.5' }, { minutes: '1e1' }, { hours: '-1' }, { hours: 24 },
    { minutes: 60 }, { seconds: 60 }, { hours: false },
    { hours: '', minutes: '', seconds: '' },
  ]) assert.throws(() => validateRun(form(changes), { now }));
});

test('validation checks actual calendar dates and the local future boundary', () => {
  assert.equal(validateRun(form({ date: '2024-02-29' }), { now }).run_date, '2024-02-29');
  assert.equal(validateRun(form({ date: '2026-10-28' }), { now }).run_date, '2026-10-28');
  for (const date of ['2026-02-29', '2026-04-31', '2026-13-01', '2026-00-01', '2026-1-01', '0000-01-01', '2026-10-29']) {
    assert.throws(() => validateRun(form({ date }), { now }));
  }
});

test('validation matches the shared database minimum run date', () => {
  assert.equal(validateRun(form({ date: '2000-01-01' }), { now }).run_date, '2000-01-01');
  assert.throws(() => validateRun(form({ date: '1999-12-31' }), { now }), /2000 onward/);
});

test('validation rejects invalid identities and categories', () => {
  for (const changes of [
    { runnerName: ' ' }, { runnerName: 'A' }, { runnerName: 'A'.repeat(61) },
    { runnerName: '<b>Asha</b>' }, { runnerName: 12 }, { runnerKey: {} }, { categoryId: '42k' },
  ]) assert.throws(() => validateRun(form(changes), { now }));
  assert.throws(() => validateRun(null, { now }));
});

test('activity links are optional HTTPS URLs without embedded credentials', () => {
  assert.equal(validateRun(form({ activityUrl: ' https://www.strava.com/activities/123 ' }), { now }).activity_url,
    'https://www.strava.com/activities/123');
  assert.equal(validateRun(form({ activityUrl: 'https://example.org/run?a=1#stats' }), { now }).activity_url,
    'https://example.org/run?a=1#stats');
  assert.equal(validateRun(form({ activityUrl: '   ' }), { now }).activity_url, null);
  for (const activityUrl of ['http://example.org/run', 'javascript:alert(1)', 'not a URL', 'https://me:secret@example.org', 5]) {
    assert.throws(() => validateRun(form({ activityUrl }), { now }));
  }
});

test('activity link length is checked after URL normalization', () => {
  const prefix = 'https://example.org/';
  const maximum = `${prefix}${'a'.repeat(2048 - prefix.length)}`;
  assert.equal(validateRun(form({ activityUrl: maximum }), { now }).activity_url.length, 2048);
  assert.throws(() => validateRun(form({ activityUrl: `${maximum}a` }), { now }), /2,048 characters/);
  const expanded = `${prefix}${'é'.repeat(400)}`;
  assert.ok(expanded.length < 2048);
  assert.ok(new URL(expanded).href.length > 2048);
  assert.throws(() => validateRun(form({ activityUrl: expanded }), { now }), /2,048 characters/);
});

test('leaderboard takes one best result per canonical runner within one category', () => {
  const runs = [
    run(),
    run({ id: 'b', runner_key: 'ASHA', runner_name: 'ASHA', duration_seconds: 1400 }),
    run({ id: 'c', category_id: '3k', duration_seconds: 900 }),
    run({ id: 'd', runner_name: 'Bela', runner_key: 'bela', duration_seconds: 1450 }),
  ];
  const rows = leaderboard(runs, { categoryId: '5k', now });
  assert.deepEqual(rows.map(({ id, rank, paceSeconds }) => [id, rank, paceSeconds]), [
    ['b', 1, 280], ['d', 2, 290],
  ]);
  assert.equal(runs[1].runner_key, 'ASHA', 'ranking must not mutate source data');
  assert.deepEqual(leaderboard(runs, { categoryId: 'unknown', now }), []);
  assert.deepEqual(leaderboard(runs, { now }).map(({ id }) => id), ['c'], 'default never mixes distances');
});

test('equal times share competition ranks, and search preserves those ranks', () => {
  const runs = [
    run(),
    run({ id: 'b', runner_name: 'Bela', runner_key: 'bela' }),
    run({ id: 'c', runner_name: 'Chloé', runner_key: 'chloé', duration_seconds: 1600 }),
  ];
  assert.deepEqual(leaderboard(runs, { categoryId: '5k', now }).map(({ rank }) => rank), [1, 1, 3]);
  const found = leaderboard(runs, { categoryId: '5k', query: ' CHLOÉ ', now });
  assert.equal(found.length, 1);
  assert.equal(found[0].rank, 3);
});

test('month filtering happens before each runner’s personal best is selected', () => {
  const runs = [
    run({ id: 'old', run_date: '2026-09-30', duration_seconds: 1200 }),
    run({ id: 'current', run_date: '2026-10-01', duration_seconds: 1500 }),
    run({ id: 'future', run_date: '2026-10-29', duration_seconds: 1000 }),
    run({ id: 'other-year', run_date: '2025-10-01', duration_seconds: 1100 }),
  ];
  assert.equal(leaderboard(runs, { categoryId: '5k', period: 'month', now })[0].id, 'current');
  assert.equal(leaderboard(runs, { categoryId: '5k', period: 'all', now })[0].id, 'other-year');
});

test('equal personal bests choose the earliest run deterministically', () => {
  const runs = [run({ id: 'later', run_date: '2026-10-21' }), run({ id: 'earlier', run_date: '2026-10-01' })];
  assert.equal(leaderboard(runs, { categoryId: '5k', now })[0].id, 'earlier');
  assert.equal(leaderboard([...runs].reverse(), { categoryId: '5k', now })[0].id, 'earlier');
});

test('malformed stored records cannot corrupt ranks or inject invalid times', () => {
  const invalid = [
    null, run({ duration_seconds: 0 }), run({ duration_seconds: -1 }), run({ duration_seconds: NaN }),
    run({ duration_seconds: '900' }), run({ run_date: '2026-02-30' }), run({ runner_name: null }),
  ];
  assert.deepEqual(leaderboard(invalid, { categoryId: '5k', now }), []);
});

test('CSV escapes punctuation and prevents formulas, including whitespace-prefixed formulas', () => {
  assert.equal(csvEscape('Asha, "Ace"'), '"Asha, ""Ace"""');
  for (const value of ['=1+1', '+cmd', '-1+2', '@SUM(A1)', '  =1+1', '\t=1+1', '\n=1+1']) {
    assert.ok(csvEscape(value).startsWith('"\''));
  }
  const csv = toCSV(leaderboard([run({ runner_name: '=HYPERLINK("bad")' })], { categoryId: '5k', now }));
  assert.ok(csv.includes('"\'=HYPERLINK(""bad"")"'));
  assert.ok(csv.includes('"25:00","5:00"'));
  assert.ok(csv.endsWith('\r\n'));
});
