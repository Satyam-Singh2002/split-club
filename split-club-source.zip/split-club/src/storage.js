// Supabase's browser-safe publishable key belongs in the apikey header, not
// Authorization. No account session or secret key is needed by this app.
export const MAX_EVIDENCE_BYTES = 5 * 1024 * 1024;
const BUCKET = 'run-evidence';
const PAGE_SIZE = 1000;
const MAX_RUNS = 5000;
const FIELDS = 'id,runner_name,runner_key,category_id,run_date,duration_seconds,activity_url,evidence_path,created_at';
const EVIDENCE_PATH = /^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}\.(jpg|png|webp)$/;

function connection(config) {
  const rawUrl = String(config?.supabaseUrl ?? '').trim();
  const key = String(config?.publishableKey ?? '').trim();
  let url;
  try {
    url = new URL(rawUrl);
  } catch {
    throw new Error('The shared leaderboard has not been configured yet.');
  }
  if (url.protocol !== 'https:' || url.username || url.password || url.search || url.hash || !/^\/?$/.test(url.pathname)) {
    throw new Error('Use the HTTPS project URL from Supabase, without a path.');
  }
  if (!/^sb_publishable_[A-Za-z0-9_-]+$/.test(key)) {
    throw new Error('Configure a Supabase publishable key beginning sb_publishable_. Never use a secret or service-role key.');
  }
  return { url: url.origin, headers: { apikey: key } };
}

export function isConfigured(config) {
  try {
    connection(config);
    return true;
  } catch {
    return false;
  }
}

export function validateEvidenceFile(file) {
  if (!file || typeof file.size !== 'number' || file.size < 1) {
    throw new Error('Choose a non-empty screenshot.');
  }
  const extension = { 'image/jpeg': 'jpg', 'image/png': 'png', 'image/webp': 'webp' }[file.type];
  if (!extension) {
    throw new Error('Screenshots must be JPG, PNG or WebP images.');
  }
  if (file.size > MAX_EVIDENCE_BYTES) {
    throw new Error('The screenshot must be 5 MB or smaller.');
  }
  return { extension, mimeType: file.type };
}

async function requestJson(url, options, networkMessage) {
  let response;
  try {
    response = await fetch(url, { ...options, cache: 'no-store' });
  } catch {
    throw new Error(networkMessage);
  }
  let data;
  try {
    data = await response.json();
  } catch {
    if (response.ok) throw new Error('The leaderboard returned an unexpected response. Refresh and try again.');
    data = null;
  }
  if (!response.ok) {
    const detail = data?.message || data?.error_description || data?.error;
    if (typeof detail === 'string' && detail.length < 300) throw new Error(detail);
    throw new Error(`The leaderboard request failed (${response.status}). Try again later.`);
  }
  return { data, response };
}

export async function listRuns(config) {
  const { url, headers } = connection(config);
  const runs = [];
  // The first request fixes an upper bound at the newest row. Later requests
  // use an immutable (created_at,id) cursor, so simultaneous new submissions do
  // not shift offset pages and silently skip existing results.
  let newest = null;
  let cursor = null;
  while (true) {
    const params = new URLSearchParams({
      select: FIELDS,
      order: 'created_at.desc,id.desc',
      limit: String(Math.min(PAGE_SIZE, MAX_RUNS - runs.length + 1)),
    });
    if (newest) params.set('created_at', `lte.${newest}`);
    if (cursor) {
      params.set('or', `(created_at.lt.${cursor.created_at},and(created_at.eq.${cursor.created_at},id.lt.${cursor.id}))`);
    }
    const { data } = await requestJson(`${url}/rest/v1/runs?${params}`, { headers },
      'Could not load the shared leaderboard. Check your connection and refresh.');
    if (!Array.isArray(data)) throw new Error('The leaderboard returned an unexpected list of runs.');
    if (!data.length) return runs;
    if (!newest) newest = data[0].created_at;
    for (const run of data) {
      if (typeof run.id !== 'string' || typeof run.created_at !== 'string') {
        throw new Error('The leaderboard returned an invalid run. Contact the organizer.');
      }
    }
    runs.push(...data);
    if (runs.length > MAX_RUNS) {
      throw new Error('This leaderboard has more than 5,000 runs. Ask the organizer to archive older results.');
    }
    cursor = data.at(-1);
    // Do not infer the end from a short page: the project's API may be set to
    // return fewer rows than PAGE_SIZE. Continue until it returns no rows.
  }
}

export function evidenceUrl(config, path) {
  if (!path || !EVIDENCE_PATH.test(path)) return null;
  const { url } = connection(config);
  return `${url}/storage/v1/object/public/${BUCKET}/${encodeURIComponent(path)}`;
}

export async function submitRun(config, run, file) {
  const { url, headers } = connection(config);
  let path = null;
  if (file) {
    const { extension, mimeType } = validateEvidenceFile(file);
    path = `${crypto.randomUUID()}.${extension}`;
    await requestJson(`${url}/storage/v1/object/${BUCKET}/${path}`, {
      method: 'POST',
      headers: { ...headers, 'Content-Type': mimeType, 'x-upsert': 'false' },
      body: file,
    }, 'Could not upload the screenshot. Check your connection before trying again.');
  }
  const { data } = await requestJson(`${url}/rest/v1/rpc/submit_run`, {
    method: 'POST',
    headers: { ...headers, 'Content-Type': 'application/json' },
    body: JSON.stringify({
      p_runner_name: run.runner_name,
      p_category_id: run.category_id,
      p_run_date: run.run_date,
      p_duration_seconds: run.duration_seconds,
      p_activity_url: run.activity_url || null,
      p_evidence_path: path,
    }),
  }, 'Could not confirm whether your run was saved. Refresh the leaderboard before submitting again.');
  // A composite-returning RPC is an object in PostgREST. Also accept the
  // one-row array returned if an installation exposes it as a row set.
  const saved = Array.isArray(data) ? data[0] : data;
  if (!saved?.id) {
    throw new Error('Could not confirm whether your run was saved. Refresh the leaderboard before submitting again.');
  }
  return saved;
}
