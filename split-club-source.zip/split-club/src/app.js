import { CATEGORIES, formatDuration, formatPace, todayISO, validateRun, leaderboard } from './model.js';
import { isConfigured, listRuns, submitRun, evidenceUrl, validateEvidenceFile } from './storage.js';

const config = window.RUN_CLUB_CONFIG ?? {};
const shared = isConfigured(config);
const hasPartialConfig = Boolean(config.supabaseUrl || config.publishableKey);
const $ = (id) => document.getElementById(id);
const state = { runs: [], demo: [], categoryId: '5k', period: 'all', query: '', loading: false, failed: false, revision: 0 };
const demoEvidence = new Map();
let previewUrl = null;
let submitting = false;

function element(tag, className, text) {
  const node = document.createElement(tag);
  if (className) node.className = className;
  if (text != null) node.textContent = text;
  return node;
}

function initials(name) {
  return name.split(/\s+/u).filter(Boolean).slice(0, 2).map((part) => [...part][0]).join('').toUpperCase();
}

function category() { return CATEGORIES.find((item) => item.id === state.categoryId); }

function dateLabel(date) {
  return new Intl.DateTimeFormat('en', { day: 'numeric', month: 'short', year: 'numeric' })
    .format(new Date(`${date}T12:00:00`));
}

function publicLink(url, label, className = 'proof-link') {
  try {
    const parsed = new URL(url);
    if (parsed.protocol !== 'https:' || parsed.username || parsed.password) return null;
    const link = element('a', className, label);
    link.href = parsed.href;
    link.target = '_blank';
    link.rel = 'noopener noreferrer';
    link.setAttribute('aria-label', `${label} (opens in a new tab)`);
    return link;
  } catch { return null; }
}

function renderTabs() {
  if ($('category-tabs').children.length === CATEGORIES.length) {
    for (const button of $('category-tabs').children) {
      button.setAttribute('aria-pressed', String(button.dataset.categoryId === state.categoryId));
    }
    return;
  }
  $('category-tabs').replaceChildren(...CATEGORIES.map((item) => {
    const button = element('button', 'distance-tab', item.label);
    button.type = 'button';
    button.dataset.categoryId = item.id;
    button.setAttribute('aria-pressed', String(item.id === state.categoryId));
    button.addEventListener('click', () => {
      state.categoryId = item.id;
      render();
    });
    return button;
  }));
}

function renderPodium(rows) {
  // Search affects the table only, so the podium always reflects the actual leaders.
  $('podium').replaceChildren(...rows.slice(0, 3).map((run, index) => {
    const card = element('article', `podium-card podium-card-${index + 1}`);
    const top = element('div', 'podium-top');
    top.append(element('span', 'podium-place', `#${run.rank}`), element('span', 'podium-tag', index === 0 ? 'SETTING THE PACE' : 'PERSONAL BEST'));
    card.append(top, element('div', 'avatar', initials(run.runner_name)), element('h3', 'podium-name', run.runner_name),
      element('p', 'podium-time', formatDuration(run.duration_seconds)),
      element('p', 'podium-pace', `${formatPace(run.duration_seconds, category().distanceKm)} /km`));
    return card;
  }));
  $('podium').hidden = rows.length === 0;
}

function renderTable(rows) {
  $('leaderboard-body').replaceChildren(...rows.map((run) => {
    const row = document.createElement('tr');
    row.append(element('td', 'rank-number', String(run.rank).padStart(2, '0')));
    const runner = element('td', 'runner-cell');
    const identity = element('div', 'runner-identity');
    identity.append(element('span', 'runner-avatar', initials(run.runner_name)), element('span', 'runner-name', run.runner_name));
    runner.append(identity);
    row.append(runner, element('td', 'time-value', formatDuration(run.duration_seconds)),
      element('td', 'pace-value', formatPace(run.duration_seconds, category().distanceKm)),
      element('td', 'secondary-text run-date-cell', dateLabel(run.run_date)));
    const proof = element('td', 'proof-cell');
    let imageUrl = demoEvidence.get(run.id);
    if (!imageUrl && shared && run.evidence_path) imageUrl = evidenceUrl(config, run.evidence_path);
    if (imageUrl) {
      const imageButton = element('button', 'proof-link', 'Screenshot ↗');
      imageButton.type = 'button';
      imageButton.addEventListener('click', () => openEvidence(imageUrl, run.runner_name));
      proof.append(imageButton);
    }
    if (run.activity_url) {
      const link = publicLink(run.activity_url, 'Activity ↗');
      if (link) proof.append(link);
    }
    if (!proof.childNodes.length) proof.append(element('span', 'secondary-text', 'Self-reported'));
    row.append(proof);
    return row;
  }));
}

function render() {
  renderTabs();
  const all = leaderboard(state.runs, { categoryId: state.categoryId, period: state.period });
  const filtered = leaderboard(state.runs, { categoryId: state.categoryId, period: state.period, query: state.query });
  renderPodium(all);
  renderTable(filtered);
  $('leaderboard-summary').textContent = `${all.length} ${all.length === 1 ? 'runner' : 'runners'} · ${category().label} · ${state.period === 'month' ? 'this month' : 'all time'} · best elapsed time per runner`;
  $('empty-state').hidden = filtered.length > 0 || state.loading || state.failed;
  if (!filtered.length) $('empty-state').textContent = state.query
    ? 'No runners match that name. Try another search.'
    : 'The starting line is open. Be the first to post a run for this distance.';
}

function setLoadStatus(message, failed = false) {
  const target = $('load-message') ?? $('load-status');
  target.textContent = message;
  $('load-status').hidden = !message;
  $('retry-load').hidden = !failed;
}

async function load() {
  if (state.loading) return;
  state.loading = true;
  state.failed = false;
  const revision = state.revision;
  let refreshAgain = false;
  setLoadStatus('Loading the leaderboard…');
  render();
  try {
    if (hasPartialConfig && !shared) throw new Error('Shared submissions are not connected. The site organizer needs to finish the public connection settings.');
    if (shared) {
      const loaded = await listRuns(config);
      // An older snapshot must not remove a run saved while this read was in
      // flight. Keep the posted result visible and immediately read again.
      if (revision === state.revision) state.runs = loaded;
      else refreshAgain = true;
    } else {
      // The single-file release embeds samples so it also works when opened locally.
      const embedded = window.RUN_CLUB_DEMO_RUNS;
      if (Array.isArray(embedded)) state.demo = structuredClone(embedded);
      else {
        const response = await fetch(new URL('../data/demo-runs.json', import.meta.url));
        if (!response.ok) throw new Error('Could not load the sample leaderboard.');
        state.demo = await response.json();
      }
      state.runs = structuredClone(state.demo);
    }
    setLoadStatus('');
  } catch (error) {
    state.failed = true;
    setLoadStatus(error.message || 'We couldn’t load the leaderboard. Please try again.', true);
  } finally {
    state.loading = false;
    render();
    if (refreshAgain) load();
  }
}

function updatePace() {
  const form = $('run-form');
  const data = new FormData(form);
  const distance = CATEGORIES.find((item) => item.id === data.get('categoryId'))?.distanceKm;
  const hours = Number(data.get('hours')), minutes = Number(data.get('minutes')), seconds = Number(data.get('seconds'));
  const valid = [hours, minutes, seconds].every(Number.isInteger) && hours >= 0 && hours <= 23
    && minutes >= 0 && minutes <= 59 && seconds >= 0 && seconds <= 59;
  const total = hours * 3600 + minutes * 60 + seconds;
  $('pace-preview').textContent = valid && total > 0 ? `${formatPace(total, distance)} /km` : '— /km';
}

function resetPreview() {
  if (previewUrl) URL.revokeObjectURL(previewUrl);
  previewUrl = null;
  $('evidence-preview').replaceChildren();
  $('evidence-preview').hidden = true;
}

function showFormError(message) {
  $('form-error').textContent = message;
  $('form-error').hidden = !message;
}

function openSubmit() {
  $('run-form').hidden = false;
  $('submit-success').hidden = true;
  showFormError('');
  $('run-category').value = state.categoryId;
  $('run-date').max = todayISO();
  if (!$('run-date').value) $('run-date').value = todayISO();
  $('submission-mode').textContent = shared
    ? 'Your name, time and any attached proof will be visible to everyone using this leaderboard.'
    : 'This is a demo. Your entry stays in this tab and disappears when you reload. Screenshots are not uploaded.';
  $('submit-run').textContent = shared ? 'Post my run ↗' : 'Add demo run ↗';
  $('submit-run').disabled = Boolean(hasPartialConfig && !shared);
  updatePace();
  $('submit-dialog').showModal();
}

function showSuccess(run) {
  $('run-form').hidden = true;
  const success = $('submit-success');
  success.replaceChildren(element('span', 'success-mark', '✓'), element('h3', '', shared ? 'Your run is on the board.' : 'Your demo run is on the board.'),
    element('p', '', `${run.runner_name} · ${CATEGORIES.find((item) => item.id === run.category_id).label} · ${formatDuration(run.duration_seconds)}`),
    element('p', 'secondary-text', shared ? 'Every finish is progress. See where your best takes you.' : 'This entry is visible only in this tab. Reloading resets the demo.'));
  const done = element('button', 'button button-primary', 'See the leaderboard');
  done.type = 'button';
  done.addEventListener('click', () => { $('submit-dialog').close(); $('leaderboard').scrollIntoView({ behavior: 'smooth' }); });
  success.append(done);
  success.hidden = false;
  done.focus();
}

async function onSubmit(event) {
  event.preventDefault();
  if (submitting) return;
  showFormError('');
  const data = new FormData($('run-form'));
  if (data.get('website')) return;
  let run, file;
  try {
    run = validateRun(Object.fromEntries(data));
    file = $('run-evidence').files[0];
    if (file) validateEvidenceFile(file);
    if (hasPartialConfig && !shared) throw new Error('Shared submissions are not connected yet.');
  } catch (error) {
    showFormError(error.message);
    return;
  }
  submitting = true;
  $('submit-run').disabled = true;
  $('submit-run').textContent = 'Posting your run…';
  try {
    let saved;
    if (shared) saved = await submitRun(config, run, file);
    else {
      const duplicate = state.runs.some((item) => item.runner_key === run.runner_key && item.category_id === run.category_id
        && item.run_date === run.run_date && item.duration_seconds === run.duration_seconds);
      if (duplicate) throw new Error('That run is already on the board.');
      saved = { ...run, id: crypto.randomUUID(), created_at: new Date().toISOString() };
      if (file) demoEvidence.set(saved.id, URL.createObjectURL(file));
    }
    state.revision += 1;
    state.runs.push(saved);
    state.categoryId = run.category_id;
    state.query = '';
    $('runner-search').value = '';
    // A run outside the current month should still be visible after submitting.
    if (state.period === 'month' && run.run_date.slice(0, 7) !== todayISO().slice(0, 7)) {
      state.period = 'all';
      $('period-filter').value = 'all';
    }
    render();
    $('run-form').reset();
    resetPreview();
    showSuccess(saved);
  } catch (error) {
    showFormError(error.message || 'Your run could not be posted. Please try again.');
  } finally {
    submitting = false;
    $('submit-run').disabled = false;
    $('submit-run').textContent = shared ? 'Post my run ↗' : 'Add demo run ↗';
  }
}

function openEvidence(url, runnerName) {
  const dialog = $('proof-dialog');
  $('proof-title').textContent = `${runnerName}’s screenshot`;
  $('proof-image').src = url;
  $('proof-image').alt = `Run screenshot submitted by ${runnerName}`;
  dialog.showModal();
}

function init() {
  const connection = $('connection-message') ?? $('connection-status');
  connection.textContent = shared ? 'Community leaderboard · self-reported results'
    : hasPartialConfig ? 'Shared submissions are not connected yet.' : 'Demo leaderboard · sample runners. New entries stay in this tab.';
  $('reset-demo').hidden = shared || hasPartialConfig;
  document.querySelectorAll('[data-open-submit]').forEach((button) => button.addEventListener('click', openSubmit));
  document.querySelectorAll('[data-close-submit]').forEach((button) => button.addEventListener('click', () => {
    if (!submitting) $('submit-dialog').close();
  }));
  $('submit-dialog').addEventListener('cancel', (event) => { if (submitting) event.preventDefault(); });
  $('submit-dialog').addEventListener('close', resetPreview);
  $('close-proof').addEventListener('click', () => $('proof-dialog').close());
  $('proof-dialog').addEventListener('close', () => { $('proof-image').removeAttribute('src'); });
  $('runner-search').addEventListener('input', (event) => { state.query = event.target.value; render(); });
  $('period-filter').addEventListener('change', (event) => { state.period = event.target.value; render(); });
  $('run-form').addEventListener('input', updatePace);
  $('run-form').addEventListener('submit', onSubmit);
  $('run-evidence').addEventListener('change', () => {
    resetPreview();
    showFormError('');
    const file = $('run-evidence').files[0];
    if (!file) return;
    try {
      validateEvidenceFile(file);
      previewUrl = URL.createObjectURL(file);
      const image = element('img');
      image.src = previewUrl;
      image.alt = 'Your selected run screenshot';
      $('evidence-preview').append(image, element('span', 'secondary-text', file.name));
      $('evidence-preview').hidden = false;
    } catch (error) { $('run-evidence').value = ''; showFormError(error.message); }
  });
  $('reset-demo').addEventListener('click', () => {
    for (const url of demoEvidence.values()) URL.revokeObjectURL(url);
    demoEvidence.clear();
    state.runs = structuredClone(state.demo);
    state.query = '';
    $('runner-search').value = '';
    render();
  });
  $('retry-load').addEventListener('click', load);
  document.addEventListener('visibilitychange', () => { if (shared && !document.hidden && !submitting) load(); });
  // Refresh shared results without rebuilding or publishing the website.
  if (shared) window.setInterval(() => { if (!document.hidden && !submitting) load(); }, 60_000);
  load();
}

init();
