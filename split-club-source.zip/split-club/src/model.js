/** Shared rules for run submissions, ranking, and exports. No browser dependencies. */
export const CATEGORIES = Object.freeze([
  Object.freeze({ id: '3k', label: '3K', distanceKm: 3 }),
  Object.freeze({ id: '5k', label: '5K', distanceKm: 5 }),
  Object.freeze({ id: '10k', label: '10K', distanceKm: 10 }),
  Object.freeze({ id: 'half', label: '21.1K', distanceKm: 21.1 }),
]);

const categoryById = new Map(CATEGORIES.map((category) => [category.id, category]));
const pad = (value) => String(value).padStart(2, '0');
const cleanSpace = (value) => value.trim().replace(/\s+/gu, ' ');
const canonicalKey = (value) => cleanSpace(value).normalize('NFKC').toLowerCase().normalize('NFC');

/** Durations are rounded to the nearest second, with hours shown when needed. */
export function formatDuration(seconds) {
  if (typeof seconds !== 'number' || !Number.isFinite(seconds) || seconds < 0) return '—';
  const total = Math.round(seconds);
  const hours = Math.floor(total / 3600);
  const minutes = Math.floor((total % 3600) / 60);
  const remainder = total % 60;
  return hours ? `${hours}:${pad(minutes)}:${pad(remainder)}` : `${minutes}:${pad(remainder)}`;
}

/** Pace is minutes per kilometre, rounded only for display. */
export function formatPace(seconds, km) {
  if (typeof seconds !== 'number' || !Number.isFinite(seconds) || seconds < 0
    || typeof km !== 'number' || !Number.isFinite(km) || km <= 0) return '—';
  const pace = Math.round(seconds / km);
  return `${Math.floor(pace / 60)}:${pad(pace % 60)}`;
}

/** Uses the viewer's local calendar date, avoiding UTC midnight shifts. */
export function todayISO(now = new Date()) {
  if (!(now instanceof Date) || !Number.isFinite(now.getTime())) {
    throw new Error('A valid current date is required.');
  }
  return `${String(now.getFullYear()).padStart(4, '0')}-${pad(now.getMonth() + 1)}-${pad(now.getDate())}`;
}

function isCalendarDate(value) {
  if (typeof value !== 'string' || !/^\d{4}-\d{2}-\d{2}$/u.test(value)) return false;
  const [year, month, day] = value.split('-').map(Number);
  if (year < 1 || month < 1 || month > 12 || day < 1) return false;
  const leap = year % 4 === 0 && (year % 100 !== 0 || year % 400 === 0);
  const days = [31, leap ? 29 : 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  return day <= days[month - 1];
}

function integerField(value, label, maximum) {
  const candidate = value == null || value === '' ? '0' : value;
  if (!['string', 'number'].includes(typeof candidate)) {
    throw new Error(`${label} must be a whole number from 0 to ${maximum}.`);
  }
  const text = String(candidate).trim();
  if (!/^\d+$/u.test(text)) {
    throw new Error(`${label} must be a whole number from 0 to ${maximum}.`);
  }
  const result = Number(text);
  if (!Number.isSafeInteger(result) || result > maximum) {
    throw new Error(`${label} must be a whole number from 0 to ${maximum}.`);
  }
  return result;
}

/**
 * Validates form values. An optional explicit runnerKey supports a stable identity;
 * otherwise a normalized display name is the identity in the local demo.
 * This is input validation, not participant identity verification.
 */
export function validateRun(input, { now = new Date() } = {}) {
  if (!input || typeof input !== 'object' || Array.isArray(input)) {
    throw new Error('Enter the run details.');
  }
  if (typeof input.runnerName !== 'string') throw new Error('Enter a runner name.');
  const runnerName = cleanSpace(input.runnerName).normalize('NFC');
  const nameLength = [...runnerName].length;
  if (nameLength < 2 || nameLength > 60) {
    throw new Error('Runner name must contain 2 to 60 characters.');
  }
  if (/[<>\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F]/u.test(runnerName)) {
    throw new Error('Use a plain-text runner name without markup.');
  }
  if (!categoryById.has(input.categoryId)) throw new Error('Choose a valid distance category.');

  const runDate = typeof input.date === 'string' ? input.date.trim() : '';
  if (!isCalendarDate(runDate)) throw new Error('Enter a valid run date.');
  if (runDate < '2000-01-01') throw new Error('Run date must be from 2000 onward.');
  if (runDate > todayISO(now)) throw new Error('Run date cannot be in the future.');

  const hours = integerField(input.hours, 'Hours', 23);
  const minutes = integerField(input.minutes, 'Minutes', 59);
  const seconds = integerField(input.seconds, 'Seconds', 59);
  const duration = hours * 3600 + minutes * 60 + seconds;
  if (duration <= 0 || duration > 86400) {
    throw new Error('Enter a finishing time greater than zero and no longer than 24 hours.');
  }

  let activityUrl = null;
  if (input.activityUrl != null && input.activityUrl !== '') {
    if (typeof input.activityUrl !== 'string') throw new Error('Enter a valid HTTPS activity link.');
    const value = input.activityUrl.trim();
    if (value) {
      let parsed;
      try { parsed = new URL(value); } catch { throw new Error('Enter a valid HTTPS activity link.'); }
      if (parsed.protocol !== 'https:' || parsed.username || parsed.password) {
        throw new Error('Activity links must use HTTPS and contain no username or password.');
      }
      if (parsed.href.length > 2048) throw new Error('Activity links must contain at most 2,048 characters.');
      activityUrl = parsed.href;
    }
  }

  if (input.runnerKey != null && typeof input.runnerKey !== 'string') {
    throw new Error('Runner identity must be text.');
  }
  const runnerKey = canonicalKey(input.runnerKey?.trim() || runnerName);
  return {
    runner_name: runnerName,
    runner_key: runnerKey,
    category_id: input.categoryId,
    run_date: runDate,
    duration_seconds: duration,
    activity_url: activityUrl,
  };
}

/**
 * Returns the fastest run per identity within one distance and calendar period.
 * Search preserves overall ranks. Ties use competition ranking (1, 1, 3).
 * The optional now value is a local Date, used for the current-month filter.
 */
export function leaderboard(runs, {
  categoryId = CATEGORIES[0].id,
  period = 'all',
  query = '',
  now = new Date(),
} = {}) {
  const category = categoryById.get(categoryId);
  if (!category || !Array.isArray(runs)) return [];
  if (!['all', 'month'].includes(period)) throw new Error('Choose all time or the current month.');
  const today = todayISO(now);
  const month = today.slice(0, 7);
  const best = new Map();

  for (const run of runs) {
    if (!run || run.category_id !== categoryId || typeof run.runner_name !== 'string'
      || !isCalendarDate(run.run_date) || run.run_date > today
      || !Number.isInteger(run.duration_seconds) || run.duration_seconds <= 0
      || run.duration_seconds > 86400) continue;
    if (period === 'month' && run.run_date.slice(0, 7) !== month) continue;
    const key = canonicalKey(typeof run.runner_key === 'string' && run.runner_key.trim()
      ? run.runner_key : run.runner_name);
    if (!key) continue;
    const previous = best.get(key);
    // For equal performances, retain the earliest run, then a stable record ID.
    if (!previous || run.duration_seconds < previous.duration_seconds
      || (run.duration_seconds === previous.duration_seconds
        && (run.run_date < previous.run_date
          || (run.run_date === previous.run_date && String(run.id ?? '') < String(previous.id ?? ''))))) {
      best.set(key, { ...run, runner_key: key });
    }
  }

  const sorted = [...best.values()].sort((a, b) => a.duration_seconds - b.duration_seconds
    || a.runner_name.localeCompare(b.runner_name)
    || a.runner_key.localeCompare(b.runner_key));
  let previousDuration;
  let rank = 0;
  const ranked = sorted.map((run, index) => {
    if (run.duration_seconds !== previousDuration) rank = index + 1;
    previousDuration = run.duration_seconds;
    return { ...run, rank, paceSeconds: run.duration_seconds / category.distanceKm };
  });
  const search = typeof query === 'string' ? canonicalKey(query) : '';
  return search ? ranked.filter((run) => canonicalKey(run.runner_name).includes(search)) : ranked;
}

/** Quotes a CSV cell and prevents spreadsheet formulas in user-controlled text. */
export function csvEscape(value) {
  let text = String(value ?? '');
  if (/^[\s\uFEFF]*[=+\-@]/u.test(text) || /^[\t\r\n]/u.test(text)) text = `'${text}`;
  return `"${text.replace(/"/gu, '""')}"`;
}

/** Exports leaderboard rows or ordinary run records as a spreadsheet-safe CSV. */
export function toCSV(runs) {
  const rows = [['Rank', 'Runner', 'Category', 'Run date', 'Time', 'Pace (min/km)', 'Activity URL']];
  for (const run of runs) {
    const category = categoryById.get(run.category_id);
    rows.push([
      run.rank ?? '', run.runner_name, category?.label ?? run.category_id, run.run_date,
      formatDuration(run.duration_seconds), formatPace(run.duration_seconds, category?.distanceKm),
      run.activity_url,
    ]);
  }
  return `${rows.map((row) => row.map(csvEscape).join(',')).join('\r\n')}\r\n`;
}
