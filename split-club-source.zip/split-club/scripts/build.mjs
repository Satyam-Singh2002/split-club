import { cp, mkdir, rm, access, readFile, writeFile } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import path from 'node:path';

const root = fileURLToPath(new URL('../', import.meta.url));
const output = path.join(root, 'dist');
const publicFiles = ['index.html', 'config.js', '.nojekyll', 'assets', 'src', 'data'];
for (const file of publicFiles) await access(path.join(root, file));
await rm(output, { recursive: true, force: true });
await mkdir(output, { recursive: true });
for (const file of publicFiles) {
  await cp(path.join(root, file), path.join(output, file), { recursive: true });
}
console.log('Built dist/ for GitHub Pages. No packages or build service required.');

// A second release is deliberately a single HTML file. It can be uploaded with
// GitHub's normal browser file picker without granting a CLI or app access.
const read = (name) => readFile(path.join(root, name), 'utf8');
const [html, css, settings, model, storage, app, samples, favicon] = await Promise.all([
  read('index.html'), read('assets/styles.css'), read('config.js'), read('src/model.js'),
  read('src/storage.js'), read('src/app.js'), read('data/demo-runs.json'), read('assets/favicon.svg'),
]);
const moduleBody = (source, names) => `(() => {\n${source.replace(/^export /gm, '')}\nreturn {${names.join(',')}};\n})()`;
const modelNames = ['CATEGORIES', 'formatDuration', 'formatPace', 'todayISO', 'validateRun', 'leaderboard'];
const storageNames = ['isConfigured', 'listRuns', 'submitRun', 'evidenceUrl', 'validateEvidenceFile'];
const bundledApp = app.replace(/^import .* from '\.\/(model|storage)\.js';\n/gm, '');
const javascript = `const {${modelNames.join(',')}} = ${moduleBody(model, modelNames)};\n`
  + `const {${storageNames.join(',')}} = ${moduleBody(storage, storageNames)};\n${bundledApp}`;
const safeScript = (source) => source.replace(/<\/script/gi, '<\\/script');
let standalone = html
  .replace(/<link rel="stylesheet" href="\.\/assets\/styles\.css"\s*\/>/, () => `<style>${css.replace(/^@charset[^;]+;\s*/, '')}</style>`)
  .replace(/href="\.\/assets\/favicon\.svg"/, () => `href="data:image/svg+xml,${encodeURIComponent(favicon)}"`)
  .replace('<script src="./config.js"></script>', () => `<script>${safeScript(settings)}\nwindow.RUN_CLUB_DEMO_RUNS = ${JSON.stringify(JSON.parse(samples)).replace(/</g, '\\u003c')};</script>`)
  .replace('<script type="module" src="./src/app.js"></script>', () => `<script type="module">${safeScript(javascript)}</script>`);
if (/src="\.\/|href="\.\/assets\//.test(standalone)) throw new Error('The single-file release still has a relative asset dependency.');
const release = path.join(root, 'release');
await mkdir(release, { recursive: true });
await writeFile(path.join(release, 'index.html'), standalone);
console.log('Built release/index.html for browser upload and offline preview.');
