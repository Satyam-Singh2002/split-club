import test from 'node:test';
import assert from 'node:assert/strict';
import { isConfigured, listRuns, submitRun, evidenceUrl, validateEvidenceFile, MAX_EVIDENCE_BYTES } from '../src/storage.js';

const config = { supabaseUrl: 'https://example.supabase.co', publishableKey: 'sb_publishable_test' };
const run = { runner_name: 'Alex Runner', category_id: '5k', run_date: '2026-10-27', duration_seconds: 1500 };
const id = '11111111-1111-4111-8111-111111111111';
const json = (body, status = 200) => new Response(JSON.stringify(body), { status, headers: { 'Content-Type': 'application/json' } });

async function withFetch(mock, task) {
  const original = globalThis.fetch;
  globalThis.fetch = mock;
  try { await task(); } finally { globalThis.fetch = original; }
}

test('configuration accepts only HTTPS project origins and browser publishable keys', () => {
  assert.equal(isConfigured(config), true);
  assert.equal(isConfigured({ ...config, supabaseUrl: `${config.supabaseUrl}/` }), true);
  assert.equal(isConfigured({}), false);
  for (const supabaseUrl of ['http://example.supabase.co', 'https://user:pass@example.supabase.co', 'https://example.supabase.co/rest/v1', 'https://example.supabase.co?apikey=x']) {
    assert.equal(isConfigured({ ...config, supabaseUrl }), false);
  }
  assert.equal(isConfigured({ ...config, publishableKey: 'sb_secret_keep-private' }), false);
});

test('evidence checks restrict format and size; public URLs cannot traverse paths', () => {
  assert.deepEqual(validateEvidenceFile(new Blob(['image'], { type: 'image/png' })), { extension: 'png', mimeType: 'image/png' });
  assert.throws(() => validateEvidenceFile({ size: 1, type: 'image/svg+xml' }), /JPG, PNG or WebP/);
  assert.throws(() => validateEvidenceFile({ size: MAX_EVIDENCE_BYTES + 1, type: 'image/jpeg' }), /5 MB/);
  assert.throws(() => validateEvidenceFile({ size: 0, type: 'image/jpeg' }), /non-empty/);
  assert.equal(evidenceUrl(config, `${id}.png`), `https://example.supabase.co/storage/v1/object/public/run-evidence/${id}.png`);
  assert.equal(evidenceUrl(config, '../private/image.png'), null);
  assert.equal(evidenceUrl(config, null), null);
});

test('reads use keyset pagination even when the server returns a short page', async () => {
  const pages = [
    [{ id, created_at: '2026-10-28T10:00:00+00:00' }],
    [{ id: '22222222-2222-4222-8222-222222222222', created_at: '2026-10-27T10:00:00+00:00' }],
    [],
  ];
  const requests = [];
  await withFetch(async (url, options) => {
    requests.push({ url: new URL(url), options });
    return json(pages.shift());
  }, async () => {
    assert.equal((await listRuns(config)).length, 2);
  });
  assert.equal(requests.length, 3);
  assert.deepEqual(requests[0].options.headers, { apikey: config.publishableKey });
  assert.equal(requests[0].url.searchParams.get('order'), 'created_at.desc,id.desc');
  assert.equal(requests[1].url.searchParams.get('created_at'), 'lte.2026-10-28T10:00:00+00:00');
  assert.match(requests[1].url.searchParams.get('or'), /id\.lt\.11111111/);
  assert.equal(requests[0].options.cache, 'no-store');
});

test('a leaderboard larger than the limit fails visibly instead of showing partial rankings', async () => {
  let calls = 0;
  await withFetch(async () => {
    calls += 1;
    if (calls <= 5) return json(Array.from({ length: 1000 }, (_, n) => ({ id: `${calls}-${n}`, created_at: '2026-10-28T00:00:00Z' })));
    return json([{ id, created_at: '2026-10-27T00:00:00Z' }]);
  }, async () => {
    await assert.rejects(listRuns(config), /more than 5,000/);
  });
});

test('submissions call the validating RPC rather than writing directly to runs', async () => {
  let request;
  await withFetch(async (url, options) => {
    request = { url, options };
    return json({ ...run, id });
  }, async () => {
    assert.equal((await submitRun(config, run)).id, id);
  });
  assert.equal(request.url, `${config.supabaseUrl}/rest/v1/rpc/submit_run`);
  assert.equal(request.options.method, 'POST');
  assert.equal(request.options.headers.Authorization, undefined);
  assert.deepEqual(JSON.parse(request.options.body), {
    p_runner_name: run.runner_name,
    p_category_id: run.category_id,
    p_run_date: run.run_date,
    p_duration_seconds: run.duration_seconds,
    p_activity_url: null,
    p_evidence_path: null,
  });
});

test('optional screenshots upload before their path is attached to the new run', async () => {
  const requests = [];
  const image = new Blob(['png'], { type: 'image/png' });
  await withFetch(async (url, options) => {
    requests.push({ url, options });
    return json(url.includes('/rpc/') ? { id } : { Key: 'uploaded' });
  }, async () => {
    await submitRun(config, run, image);
  });
  assert.equal(requests.length, 2);
  assert.match(requests[0].url, /\/storage\/v1\/object\/run-evidence\/[a-f0-9-]+\.png$/);
  assert.equal(requests[0].options.body, image);
  assert.equal(requests[0].options.headers['x-upsert'], 'false');
  const filename = requests[0].url.split('/').at(-1);
  assert.equal(JSON.parse(requests[1].options.body).p_evidence_path, filename);
});

test('upload failure stops submission and database errors remain useful to the runner', async () => {
  let calls = 0;
  await withFetch(async () => { calls += 1; return json({ message: 'Storage quota exceeded' }, 413); }, async () => {
    await assert.rejects(submitRun(config, run, new Blob(['image'], { type: 'image/jpeg' })), /Storage quota exceeded/);
  });
  assert.equal(calls, 1);
  await withFetch(async () => json({ message: 'This run has already been submitted. Check the leaderboard.' }, 400), async () => {
    await assert.rejects(submitRun(config, run), /already been submitted/);
  });
});

test('uncertain submission failures do not retry and tell the runner to check saved results', async () => {
  let calls = 0;
  await withFetch(async () => { calls += 1; throw new TypeError('Failed to fetch'); }, async () => {
    await assert.rejects(submitRun(config, run), /Refresh the leaderboard before submitting again/);
  });
  assert.equal(calls, 1);
});
