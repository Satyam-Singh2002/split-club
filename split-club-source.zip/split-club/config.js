// Only public settings belong here. Never put a GitHub token, database password,
// Supabase secret key, or service_role key in this file or in browser code.
// Leave these empty to run the explicitly labelled, device-local demo.
window.RUN_CLUB_CONFIG = Object.freeze({
  supabaseUrl: "",
  publishableKey: ""
});
